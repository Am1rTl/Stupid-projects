'use client'

import { useState, useEffect, useCallback, useRef } from 'react'

interface Bubble {
  id: number
  isPopped: boolean
  row: number
  col: number
}

export default function DigitalBubbleWrap() {
  const [bubbles, setBubbles] = useState<Bubble[]>([])
  const [totalPops, setTotalPops] = useState(0)
  const [isSoundEnabled, setIsSoundEnabled] = useState(true)
  const audioContextRef = useRef<AudioContext | null>(null)

  // Initialize audio context
  useEffect(() => {
    if (typeof window !== 'undefined') {
      audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)()
    }
    return () => {
      if (audioContextRef.current) {
        audioContextRef.current.close()
      }
    }
  }, [])

  // Generate pop sound using Web Audio API
  const playPopSound = useCallback(() => {
    if (!isSoundEnabled || !audioContextRef.current) return

    const audioContext = audioContextRef.current
    const oscillator = audioContext.createOscillator()
    const gainNode = audioContext.createGain()

    oscillator.connect(gainNode)
    gainNode.connect(audioContext.destination)

    // Create a satisfying pop sound
    oscillator.frequency.setValueAtTime(200, audioContext.currentTime)
    oscillator.frequency.exponentialRampToValueAtTime(50, audioContext.currentTime + 0.1)

    gainNode.gain.setValueAtTime(0.3, audioContext.currentTime)
    gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.1)

    oscillator.start(audioContext.currentTime)
    oscillator.stop(audioContext.currentTime + 0.1)
  }, [isSoundEnabled])

  // Initialize bubbles
  useEffect(() => {
    const rows = 8
    const cols = 12
    const initialBubbles: Bubble[] = []
    
    for (let row = 0; row < rows; row++) {
      for (let col = 0; col < cols; col++) {
        initialBubbles.push({
          id: row * cols + col,
          isPopped: false,
          row,
          col
        })
      }
    }
    
    setBubbles(initialBubbles)
  }, [])

  // Handle bubble pop
  const popBubble = useCallback((id: number) => {
    setBubbles(prev => prev.map(bubble => 
      bubble.id === id && !bubble.isPopped 
        ? { ...bubble, isPopped: true }
        : bubble
    ))
    setTotalPops(prev => prev + 1)
    playPopSound()

    // Regenerate the bubble after a delay
    setTimeout(() => {
      setBubbles(prev => prev.map(bubble => 
        bubble.id === id 
          ? { ...bubble, isPopped: false }
          : bubble
      ))
    }, 2000)
  }, [playPopSound])

  // Reset all bubbles
  const resetAll = useCallback(() => {
    setBubbles(prev => prev.map(bubble => ({ ...bubble, isPopped: false })))
    setTotalPops(0)
  }, [])

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-pink-50 to-blue-50 p-4">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8 pt-8">
          <h1 className="text-4xl md:text-6xl font-bold text-gray-800 mb-4">
            Digital Bubble Wrap 🫧
          </h1>
          <p className="text-lg md:text-xl text-gray-600 mb-6">
            Click the bubbles to pop them! They'll regenerate after 2 seconds.
          </p>
          
          {/* Stats and Controls */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-6">
            <div className="bg-white rounded-lg px-6 py-3 shadow-md">
              <span className="text-gray-600">Total Pops: </span>
              <span className="text-2xl font-bold text-purple-600">{totalPops}</span>
            </div>
            
            <button
              onClick={() => setIsSoundEnabled(!isSoundEnabled)}
              className="bg-white rounded-lg px-6 py-3 shadow-md hover:shadow-lg transition-shadow"
            >
              {isSoundEnabled ? '🔊 Sound On' : '🔇 Sound Off'}
            </button>
            
            <button
              onClick={resetAll}
              className="bg-white rounded-lg px-6 py-3 shadow-md hover:shadow-lg transition-shadow"
            >
              🔄 Reset All
            </button>
          </div>
        </div>

        {/* Bubble Wrap Grid */}
        <div className="flex justify-center mb-8">
          <div className="inline-block bg-white p-6 rounded-2xl shadow-xl">
            <div className="grid grid-cols-12 gap-1 sm:gap-2">
              {bubbles.map((bubble) => (
                <button
                  key={bubble.id}
                  onClick={() => popBubble(bubble.id)}
                  className={`
                    relative w-8 h-8 sm:w-10 sm:h-10 md:w-12 md:h-12 rounded-full
                    transition-all duration-200 transform
                    ${bubble.isPopped 
                      ? 'bg-gray-200 scale-75 shadow-inner' 
                      : 'bg-gradient-to-br from-blue-400 to-blue-600 hover:from-blue-500 hover:to-blue-700 shadow-lg hover:shadow-xl hover:scale-110 active:scale-95'
                    }
                    border-2 border-blue-300
                    focus:outline-none focus:ring-2 focus:ring-blue-400 focus:ring-offset-2
                  `}
                  disabled={bubble.isPopped}
                >
                  {!bubble.isPopped && (
                    <div className="absolute inset-0 rounded-full bg-white opacity-30 blur-sm" />
                  )}
                  {bubble.isPopped && (
                    <div className="absolute inset-0 flex items-center justify-center">
                      <span className="text-xs text-gray-400">✨</span>
                    </div>
                  )}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Instructions */}
        <div className="text-center text-gray-600">
          <p className="mb-2">💡 <strong>Tip:</strong> Try popping bubbles in patterns or as fast as you can!</p>
          <p className="text-sm">Each bubble makes a satisfying pop sound and automatically regenerates.</p>
        </div>

        {/* Fun Messages based on pop count */}
        {totalPops > 0 && (
          <div className="text-center mt-8">
            <div className="inline-block bg-yellow-100 rounded-lg px-6 py-3 shadow-md">
              {totalPops < 10 && <p className="text-lg">🎯 Getting started!</p>}
              {totalPops >= 10 && totalPops < 50 && <p className="text-lg">🔥 Keep going!</p>}
              {totalPops >= 50 && totalPops < 100 && <p className="text-lg">⭐ Bubble popping master!</p>}
              {totalPops >= 100 && totalPops < 200 && <p className="text-lg">🏆 Legendary popper!</p>}
              {totalPops >= 200 && <p className="text-lg">👑 You are the Bubble King/Queen!</p>}
            </div>
          </div>
        )}
      </div>
    </div>
  )
}